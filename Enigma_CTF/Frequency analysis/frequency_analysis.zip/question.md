---
Category: "Cryptography"
Title: "Substitute"
CID: ""
Version: 1
Author: "K S Ananth"
Summary: "It's all right there!; Note: Maintain the flag format."
Points: 
Flag: "enigma24{Y0U4RELUCKYTBHT04TTENDCYBERC0N24}"
sha256: ""
Hints: "[The key is the present competition!]"
weight: 
---

Join The kludge Community [whatsapp](https://chat.whatsapp.com/BoGjuUDnDQu3XyZqA6azxM) and [discord](https://discord.gg/nM5377wjQR) (Go to [announcements](https://discord.com/channels/919858757901643849/1120219125592096879) channel in Challenge group for rules). Stay tuned and keep solving!  

Let's start the journey! We are together in this.  
Solve! Enjoy! Learn!
